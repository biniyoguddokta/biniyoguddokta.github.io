# সমিতি অ্যাপ — Part 1 (Flutter UI / Build Checkpoint)

এই প্যাকেজটি প্রথম Codespaces/GitHub Actions build checkpoint। এতে আগের Batch 1 ZIP-এর Flutter source রাখা হয়েছে। Google Apps Script backend ইচ্ছাকৃতভাবে বাদ: backend/Code.gs, Firebase, migration, OAuth এবং server-side security পরবর্তী backend পর্যায়ে করা হবে।

## এই প্যাকেজে থাকা পরিবর্তন
- Dashboard-এর banner carousel ও notice strip-এর বদলে Recent Investments panel।
- Dashboard-এর ফান্ড মডিউল Investment screen-এর সঙ্গে সংযুক্ত।
- Dashboard-এ transactions, members ও investments request একসঙ্গে শুরু হয়।
- Splash/login routing থেকে নির্দিষ্ট ২ সেকেন্ডের wait সরানো হয়েছে।
- Installment collection dialog-এ scroll support ও payment data handling উন্নত।
- Investment screen-এ কিস্তিতে পণ্যের চুক্তি/বিক্রয়ের তথ্য দেখানো।
- All Transactions-এ শুধু পরিশোধিত রেকর্ড দেখানো।
- Manual late-fee UI validation/success handling উন্নত।

## গুরুত্বপূর্ণ সীমা
- `কিস্তিতে পণ্য` screen-এর বর্তমান design/layout অপরিবর্তিত রাখা হয়েছে।
- এই ZIP-এ Google Apps Script `Code.gs` নেই। ফলে automatic ৫০ টাকা জরিমানা বন্ধ করার server-side পরিবর্তন এই ZIP upload করলেই কার্যকর হবে না। সেটি backend পর্যায়ে আলাদাভাবে deploy করতে হবে।
- এই checkpoint-এ Member 360°, Digital Receipt PDF, Pledge Documents, Advanced Reports, Smart Search, Export, Dark Mode, Localization, Firebase, Backup, Audit Log এবং Push Notification সম্পন্ন হয়েছে—এমন দাবি করা হচ্ছে না। এগুলো পরবর্তী কাজের scope।

## Build যাচাই
এই পরিবেশে Flutter/Dart SDK নেই, তাই APK build বা `flutter analyze` চালানো যায়নি। Codespaces-এ project root-এ গিয়ে চালান:

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

GitHub Actions build-ও চালাতে পারেন। Build log-এর error থাকলে পরবর্তী ধাপে সেটি ঠিক করে Part 2-তে এগোনো হবে।
