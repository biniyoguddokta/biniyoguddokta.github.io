import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class LateFeeScreen extends StatefulWidget {
  const LateFeeScreen({super.key});

  @override
  State<LateFeeScreen> createState() => _LateFeeScreenState();
}

class _LateFeeScreenState extends State<LateFeeScreen> {
  List<dynamic> lateFees = [];
  List<dynamic> members = [];
  bool isLoading = true;
  String userRole = "Member";
  
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();
  String? _selectedMember;
  String _status = "Unpaid"; 

  @override
  void initState() {
    super.initState();
    _loadUser();
    _fetchData();
  }

  void _loadUser() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => userRole = prefs.getString('userRole') ?? "Member");
  }

  void _fetchData() async {
    setState(() => isLoading = true);
    var res = await ApiService.getTransactions();
    var memRes = await ApiService.getAllMembers();
    
    if (!mounted) return;
    if (res is List && memRes is List) {
      setState(() {
        // 🔥 এখানে ফিল্টারিং লজিক আপডেট করা হয়েছে 🔥
        lateFees = res.where((tx) {
          final type = (tx['Type'] ?? '').toString().trim();
          final note = (tx['Note'] ?? '').toString().trim();
          // নতুন ম্যানুয়াল জরিমানা এবং আগের অটো-জেনারেট হওয়া জরিমানার রেকর্ড
          // দেখাবে; সাধারণ মাসিক বকেয়া কখনো Late Fee হিসেবে দেখাবে না।
          final isLateFeeType = type == 'বিলম্ব ফী' || type == 'বিলম্ব ফি' || type == 'জরিমানা';
          return isLateFeeType && note.toLowerCase().contains('বিলম্ব');
        }).toList().reversed.toList();
        
        members = memRes;
        isLoading = false;
      });
    } else {
      setState(() => isLoading = false);
    }
  }

  void _generateAutoDue() async {
    setState(() => isLoading = true);
    var res = await ApiService.generateAutoDue();
    if (!mounted) return;
    setState(() => isLoading = false);

    if (res['status'] == "success") {
      _fetchData();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['message'] ?? "সফলভাবে বকেয়া তৈরি হয়েছে!"), backgroundColor: Colors.green));
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['message'] ?? "সমস্যা"), backgroundColor: Colors.red));
    }
  }

  void _addLateFee() async {
    final amount = num.tryParse(_amountController.text.trim());
    if (_selectedMember == null || amount == null || amount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("সদস্য এবং পরিমাণ নির্বাচন করুন"), backgroundColor: Colors.orange));
      return;
    }

    setState(() => isLoading = true);
    
    var res = await ApiService.addTransaction(
      type: 'বিলম্ব ফী',
      amount: amount.toString(),
      note: _noteController.text.trim().isEmpty ? 'ম্যানুয়াল বিলম্ব ফী' : 'বিলম্ব ফী: ${_noteController.text.trim()}', 
      memberName: _selectedMember!,
      status: _status, 
      date: DateFormat('yyyy-MM-dd').format(DateTime.now()),
      paymentMethod: 'HAND CASH', 
    );
    
    if (!mounted) return;
    setState(() => isLoading = false);

    if (res['status'] == "success" || res['message'] == "Success (302)") {
      _amountController.clear();
      _noteController.clear();
      setState(() => _selectedMember = null);
      _fetchData();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("বিলম্ব ফী যোগ হয়েছে!"), backgroundColor: Colors.green));
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['message'] ?? "সমস্যা"), backgroundColor: Colors.red));
    }
  }

  // 🔥 পপ-আপ দেখানোর ফাংশন
  void _showConfirmPaymentDialog(String rowIndex, String memberName, String amount) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("নিশ্চিত করুন", style: TextStyle(fontWeight: FontWeight.bold)),
        content: Text("আপনি কি $memberName এর $amount টাকা পেয়েছেন?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context), 
            child: const Text("বাতিল", style: TextStyle(color: Colors.grey))
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00796B)),
            onPressed: () {
              Navigator.pop(context); // পপ-আপ বন্ধ করবে
              _processPayment(rowIndex); // পেমেন্ট প্রসেস করবে
            },
            child: const Text("কনফার্ম করুন", style: TextStyle(color: Colors.white)),
          )
        ],
      ),
    );
  }

  // 🔥 আসল পেমেন্ট প্রসেস (API কল)
  void _processPayment(String rowIndex) async {
    if (!mounted) return;
    setState(() => isLoading = true);
    var res = await ApiService.updateTransactionStatus(rowIndex: rowIndex, status: 'Paid');
    if (!mounted) return;

    if (res['status'] == 'success' || res['message'] == 'Updated' || (res['message'] ?? '').toString().contains("302")) {
      _fetchData(); // ডেটা রিফ্রেশ করবে
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("সফলভাবে পরিশোধ হয়েছে!"), backgroundColor: Colors.green));
    } else {
      setState(() => isLoading = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("পরিশোধ করতে সমস্যা হয়েছে!"), backgroundColor: Colors.red));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),
      appBar: AppBar(
        title: const Text("বিলম্ব ফী"), 
        backgroundColor: const Color(0xFF00796B), 
        foregroundColor: Colors.white,
        actions: [
          if (userRole == 'Admin')
            IconButton(
              tooltip: "শুধু মাসিক বকেয়া তৈরি করুন (জরিমানা নয়)",
              icon: const Icon(Icons.autorenew),
              onPressed: _generateAutoDue,
            )
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                if (userRole == 'Admin')
                  Container(
                    padding: const EdgeInsets.all(15),
                    color: Colors.white,
                    child: Column(
                      children: [
                        DropdownButtonFormField<String>(
                          decoration: InputDecoration(labelText: "সদস্য নির্বাচন করুন", border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
                          value: _selectedMember,
                          items: members.map((m) => DropdownMenuItem(value: m['Name'].toString(), child: Text(m['Name'].toString()))).toList(),
                          onChanged: (val) => setState(() => _selectedMember = val),
                        ),
                        const SizedBox(height: 10),
                        TextField(controller: _amountController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: "পরিমাণ (৳)", border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
                        const SizedBox(height: 10),
                        TextField(controller: _noteController, decoration: InputDecoration(labelText: "কারণ / নোট", border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)))),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          value: _status,
                          decoration: InputDecoration(labelText: "স্ট্যাটাস (Paid/Unpaid)", border: OutlineInputBorder(borderRadius: BorderRadius.circular(10))),
                          items: const [
                            DropdownMenuItem(value: "Paid", child: Text("পরিশোধিত (Paid)")),
                            DropdownMenuItem(value: "Unpaid", child: Text("বাকি (Unpaid)")),
                          ],
                          onChanged: (val) => setState(() => _status = val!),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00796B)),
                            onPressed: _addLateFee,
                            child: const Text("যোগ করুন", style: TextStyle(color: Colors.white)),
                          ),
                        )
                      ],
                    ),
                  ),
                Expanded(
                  child: lateFees.isEmpty
                      ? const Center(child: Text("কোনো বিলম্ব ফী নেই"))
                      : ListView.builder(
                          padding: const EdgeInsets.all(15),
                          itemCount: lateFees.length,
                          itemBuilder: (context, index) {
                            var fee = lateFees[index];
                            bool isPaid = fee['Status'] == 'Paid';
                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: ListTile(
                                leading: Icon(Icons.warning, color: isPaid ? Colors.green : Colors.red),
                                title: Text(fee['MemberName'].toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                                subtitle: Text(fee['Note'].toString()),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text("৳ ${fee['Amount']}", style: TextStyle(color: isPaid ? Colors.green : Colors.red, fontWeight: FontWeight.bold)),
                                        if (isPaid) ...[
                                          const Text("Paid", style: TextStyle(fontSize: 10, color: Colors.green)),
                                          Text(fee['Date'].toString().split(' ')[0], style: const TextStyle(fontSize: 10, color: Colors.grey)),
                                        ] else ...[
                                          const Text("Unpaid", style: TextStyle(fontSize: 10, color: Colors.red)),
                                        ]
                                      ],
                                    ),
                                    // 🔥 এখানে পপ-আপ কল করা হলো
                                    if (!isPaid && userRole == 'Admin') ...[
                                      const SizedBox(width: 10),
                                      ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.green,
                                          padding: const EdgeInsets.symmetric(horizontal: 10),
                                        ),
                                        onPressed: () => _showConfirmPaymentDialog(
                                          fee['RowIndex'].toString(), 
                                          fee['MemberName'].toString(), 
                                          fee['Amount'].toString()
                                        ),
                                        child: const Text("পরিশোধ", style: TextStyle(color: Colors.white, fontSize: 12)),
                                      )
                                    ]
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                )
              ],
            ),
    );
  }
}