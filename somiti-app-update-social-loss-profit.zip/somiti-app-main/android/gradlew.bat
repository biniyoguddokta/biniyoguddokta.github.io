@echo off
setlocal
set GRADLE_VERSION=8.7
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_HOME=%GRADLE_USER_HOME%\wrapper\manual\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\wrapper\manual" mkdir "%GRADLE_USER_HOME%\wrapper\manual"
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\wrapper\manual\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%GRADLE_USER_HOME%\wrapper\manual\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_USER_HOME%\wrapper\manual'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
